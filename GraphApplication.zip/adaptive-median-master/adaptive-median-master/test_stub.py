# -*- coding: utf-8 -*-

import pytest


def test_adaptive_median():
    assert True
